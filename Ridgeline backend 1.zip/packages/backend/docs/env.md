# Backend Environment Variables

Create a `.env` file in `packages/backend/`:

```
DATABASE_URL=postgresql://USER:PASSWORD@localhost:5432/ridgeline
JWT_SECRET=your_jwt_secret_here
FRONTEND_URL=http://localhost:3000

AWS_REGION=us-east-1
AWS_BUCKET=your_bucket_name
AWS_ACCESS_KEY_ID=AKIA...
AWS_SECRET_ACCESS_KEY=...
```

- **DATABASE_URL**: PostgreSQL connection
- **JWT_SECRET**: JWT signing key
- **FRONTEND_URL**: Next.js origin for CORS
- **AWS_***: S3 credentials for document uploads
``` ````

```prisma name=packages/backend/prisma/schema.prisma
datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}

generator client {
  provider = "prisma-client-js"
}

model User {
  id        String   @id @default(uuid())
  name      String
  email     String   @unique
  password  String
  role      Role     @default(USER)
  createdAt DateTime @default(now())
  claims    Claim[]  @relation("UserClaims")
}

model Client {
  id          String   @id @default(uuid())
  name        String
  contactName String
  email       String   @unique
  phone       String?
  claims      Claim[]  @relation("ClientClaims")
}

model Claim {
  id         String              @id @default(uuid())
  title      String
  status     ClaimStatus         @default(pending)
  client     Client              @relation("ClientClaims", fields: [clientId], references: [id])
  clientId   String
  owner      User                @relation("UserClaims", fields: [ownerId], references: [id])
  ownerId    String
  estimate   EstimateLineItem[]
  documents  Document[]
  createdAt  DateTime            @default(now())
  updatedAt  DateTime            @updatedAt
}

model EstimateLineItem {
  id          String   @id @default(uuid())
  description String
  quantity    Int
  unitPrice   Float
  specCode    String?
  project     Claim    @relation(fields: [projectId], references: [id])
  projectId   String
  createdAt   DateTime @default(now())
}

model Document {
  id         String   @id @default(uuid())
  filename   String
  url        String
  project    Claim    @relation(fields: [projectId], references: [id])
  projectId  String
  createdAt  DateTime @default(now())
}

enum Role {
  USER
  ADJUSTER
  ADMIN
}

enum ClaimStatus {
  pending
  in_progress
  completed
}
```

```typescript name=packages/backend/src/prisma.ts
import { PrismaClient } from '@prisma/client';

export const prisma = new PrismaClient();
```

```typescript name=packages/backend/src/services/ai.ts
// Stub AI service for approval probability
export async function estimateApprovalProbability(description: string): Promise<number> {
  // TODO: swap with real AI integration
  return 60 + Math.floor(Math.random() * 31);
}
```

```typescript name=packages/backend/src/middleware/logger.ts
import winston from 'winston';

export const logger = winston.createLogger({
  level: process.env.NODE_ENV === 'production' ? 'info' : 'debug',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.printf(
      ({ timestamp, level, message }) => `[${timestamp}] ${level.toUpperCase()}: ${message}`
    )
  ),
  transports: [new winston.transports.Console()],
});
```

```typescript name=packages/backend/src/middleware/errorHandler.ts
import { Request, Response, NextFunction } from 'express';
import { logger } from './logger';

export function errorHandler(err: any, req: Request, res: Response, next: NextFunction) {
  logger.error(err.stack || err.message || err);
  const status = err.status || 500;
  res.status(status).json({
    error: {
      message: err.message || 'Internal Server Error',
      details: err.details || null,
    },
  });
}
```

```typescript name=packages/backend/src/middleware/auth.ts
import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';

export interface AuthRequest extends Request {
  user?: { sub: string; email: string; role: string };
}

export function jwtGuard(req: AuthRequest, res: Response, next: NextFunction) {
  const token = req.cookies?.token || req.headers.authorization?.split(' ')[1];
  if (!token) {
    return res.status(401).json({ message: 'Authentication required' });
  }
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET!) as AuthRequest['user'];
    req.user = payload;
    next();
  } catch {
    return res.status(401).json({ message: 'Invalid or expired token' });
  }
}
```

```typescript name=packages/backend/src/middleware/rbac.ts
import { Response, NextFunction } from 'express';
import { AuthRequest } from './auth';

const hierarchy = { USER: 0, ADJUSTER: 1, ADMIN: 2 };

export function requireRole(minRole: 'ADJUSTER' | 'ADMIN') {
  return (req: AuthRequest, res: Response, next: NextFunction) => {
    const role = req.user?.role as keyof typeof hierarchy;
    if (hierarchy[role] < hierarchy[minRole]) {
      return res.status(403).json({ message: 'Forbidden: insufficient role' });
    }
    next();
  };
}
```

```typescript name=packages/backend/src/routes/index.ts
import { Router } from 'express';
import authRouter from './auth';
import clientsRouter from './clients';
import claimsRouter from './claims';
import projectsRouter from './projects';

const router = Router();

router.use('/auth', authRouter);
router.use('/clients', clientsRouter);
router.use('/claims', claimsRouter);
router.use('/projects', projectsRouter);

export default router;
```

```typescript name=packages/backend/src/routes/auth.ts
import { Router } from 'express';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import { z } from 'zod';
import { prisma } from '../prisma';

const router = Router();

const SignupSchema = z.object({
  name: z.string().min(2),
  email: z.string().email(),
  password: z.string().min(6)
});

router.post('/signup', async (req, res, next) => {
  try {
    const { name, email, password } = SignupSchema.parse(req.body);
    const hash = await bcrypt.hash(password, 10);
    const user = await prisma.user.create({ data: { name, email, password: hash } });
    const token = jwt.sign({ sub: user.id, email: user.email, role: user.role }, process.env.JWT_SECRET!, { expiresIn: '7d' });
    res.cookie('token', token, { httpOnly: true, secure: process.env.NODE_ENV === 'production', sameSite: 'lax', maxAge: 7 * 24 * 60 * 60 * 1000 });
    res.json({ user: { id: user.id, name: user.name, email: user.email, role: user.role } });
  } catch (err) {
    next(err);
  }
});

const LoginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(6)
});

router.post('/login', async (req, res, next) => {
  try {
    const { email, password } = LoginSchema.parse(req.body);
    const user = await prisma.user.findUnique({ where: { email } });
    if (!user || !(await bcrypt.compare(password, user.password))) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }
    const token = jwt.sign({ sub: user.id, email: user.email, role: user.role }, process.env.JWT_SECRET!, { expiresIn: '7d' });
    res.cookie('token', token, { httpOnly: true, secure: process.env.NODE_ENV === 'production', sameSite: 'lax', maxAge: 7 * 24 * 60 * 60 * 1000 });
    res.json({ user: { id: user.id, name: user.name, email: user.email, role: user.role } });
  } catch (err) {
    next(err);
  }
});

router.post('/logout', (req, res) => {
  res.clearCookie('token', { sameSite: 'lax', secure: process.env.NODE_ENV === 'production' });
  res.json({ message: 'Logged out' });
});

export default router;
```

```typescript name=packages/backend/src/routes/clients.ts
import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../prisma';
import { jwtGuard } from '../middleware/auth';

const router = Router();
router.use(jwtGuard);

const ClientSchema = z.object({
  name: z.string().min(1),
  contactName: z.string().min(1),
  email: z.string().email(),
  phone: z.string().optional()
});

router.get('/', async (req, res, next) => {
  try {
    const clients = await prisma.client.findMany();
    res.json(clients);
  } catch (err) {
    next(err);
  }
});

router.post('/', async (req, res, next) => {
  try {
    const data = ClientSchema.parse(req.body);
    const client = await prisma.client.create({ data });
    res.status(201).json(client);
  } catch (err) {
    next(err);
  }
});

router.get('/:id', async (req, res, next) => {
  try {
    const client = await prisma.client.findUniqueOrThrow({ where: { id: req.params.id } });
    res.json(client);
  } catch (err) {
    next(err);
  }
});

router.put('/:id', async (req, res, next) => {
  try {
    const data = ClientSchema.parse(req.body);
    const client = await prisma.client.update({ where: { id: req.params.id }, data });
    res.json(client);
  } catch (err) {
    next(err);
  }
});

router.delete('/:id', async (req, res, next) => {
  try {
    await prisma.client.delete({ where: { id: req.params.id } });
    res.status(204).end();
  } catch (err) {
    next(err);
  }
});

export default router;
```

```typescript name=packages/backend/src/routes/claims.ts
import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../prisma';
import { jwtGuard } from '../middleware/auth';

const router = Router();
router.use(jwtGuard);

const ClaimSchema = z.object({
  title: z.string().min(1),
  status: z.enum(['pending', 'in_progress', 'completed']).optional(),
  clientId: z.string().uuid()
});

router.get('/', async (req, res, next) => {
  try {
    const claims = await prisma.claim.findMany({
      include: { client: true, estimate: true, documents: true }
    });
    res.json(claims);
  } catch (err) {
    next(err);
  }
});

router.post('/', async (req, res, next) => {
  try {
    const data = ClaimSchema.parse(req.body);
    const ownerId = (req as any).user.sub;
    const claim = await prisma.claim.create({ data: { ...data, ownerId }, include: { client: true } });
    res.status(201).json(claim);
  } catch (err) {
    next(err);
  }
});

router.get('/:id', async (req, res, next) => {
  try {
    const claim = await prisma.claim.findUniqueOrThrow({
      where: { id: req.params.id },
      include: { client: true, estimate: true, documents: true }
    });
    res.json(claim);
  } catch (err) {
    next(err);
  }
});

router.put('/:id', async (req, res, next) => {
  try {
    const data = ClaimSchema.parse(req.body);
    const claim = await prisma.claim.update({
      where: { id: req.params.id },
      data,
      include: { client: true }
    });
    res.json(claim);
  } catch (err) {
    next(err);
  }
});

router.delete('/:id', async (req, res, next) => {
  try {
    await prisma.claim.delete({ where: { id: req.params.id } });
    res.status(204).end();
  } catch (err) {
    next(err);
  }
});

export default router;
```

```typescript name=packages/backend/src/routes/projects.ts
import { Router } from 'express';
import AWS from 'aws-sdk';
import { prisma } from '../prisma';
import { jwtGuard } from '../middleware/auth';
import { estimateApprovalProbability } from '../services/ai';

const router = Router();
router.use(jwtGuard);

const s3 = new AWS.S3({ region: process.env.AWS_REGION });

router.get('/:id/estimate', async (req, res, next) => {
  try {
    const items = await prisma.estimateLineItem.findMany({ where: { projectId: req.params.id } });
    res.json(items);
  } catch (err) {
    next(err);
  }
});

router.post('/:id/estimate', async (req, res, next) => {
  try {
    const { description, quantity, unitPrice, specCode } = req.body;
    const probability = await estimateApprovalProbability(description);
    const item = await prisma.estimateLineItem.create({
      data: {
        projectId: req.params.id,
        description,
        quantity: Number(quantity),
        unitPrice: Number(unitPrice),
        specCode
      }
    });
    res.status(201).json({ ...item, probability });
  } catch (err) {
    next(err);
  }
});

router.put('/:id/estimate/:itemId', async (req, res, next) => {
  try {
    const { description, quantity, unitPrice, specCode } = req.body;
    const item = await prisma.estimateLineItem.update({
      where: { id: req.params.itemId },
      data: { description, quantity: Number(quantity), unitPrice: Number(unitPrice), specCode }
    });
    res.json(item);
  } catch (err) {
    next(err);
  }
});

router.delete('/:id/estimate/:itemId', async (req, res, next) => {
  try {
    await prisma.estimateLineItem.delete({ where: { id: req.params.itemId } });
    res.status(204).end();
  } catch (err) {
    next(err);
  }
});

router.post('/:id/documents/presign', async (req, res, next) => {
  try {
    const { filename } = req.body;
    const key = `${req.params.id}/${Date.now()}_${filename}`;
    const url = await s3.getSignedUrlPromise('putObject', {
      Bucket: process.env.AWS_BUCKET!,
      Key: key,
      Expires: 60
    });
    res.json({ url, key });
  } catch (err) {
    next(err);
  }
});

router.get('/:id/documents', async (req, res, next) => {
  try {
    const docs = await prisma.document.findMany({ where: { projectId: req.params.id } });
    res.json(docs);
  } catch (err) {
    next(err);
  }
});

router.post('/:id/documents', async (req, res, next) => {
  try {
    const { filename, url } = req.body;
    const doc = await prisma.document.create({ data: { projectId: req.params.id, filename, url } });
    res.status(201).json(doc);
  } catch (err) {
    next(err);
  }
});

export default router;
```

```typescript name=packages/backend/src/server.ts
import express from 'express';
import cors from 'cors';
import cookieParser from 'cookie-parser';
import morgan from 'morgan';
import dotenv from 'dotenv';
import routes from './routes';
import { errorHandler } from './middleware/errorHandler';
import { logger } from './middleware/logger';

dotenv.config();

const app = express();

app.use(morgan('dev'));
app.use(cookieParser());
app.use(express.json());
app.use(
  cors({
    origin: process.env.FRONTEND_URL,
    credentials: true
  })
);

app.use('/api', routes);
app.use(errorHandler);

const port = process.env.PORT || 4000;
app.listen(port, () => logger.info(`🚀 Backend listening on http://localhost:${port}/api`));

export default app;
```

```yaml name=packages/backend/jest.config.ts
export default {
  preset: 'ts-jest',
  testEnvironment: 'node',
  testMatch: ['**/__tests__/**/*.test.ts'],
  coverageDirectory: 'coverage'
};
```

After adding these files, run from `packages/backend`:

```bash
pnpm install
pnpm prisma generate
pnpm prisma migrate dev
pnpm dev
```

Your backend will now live under `packages/backend` and be fully wired to the Ridgeline monorepo. Let me know if you need any adjustments!